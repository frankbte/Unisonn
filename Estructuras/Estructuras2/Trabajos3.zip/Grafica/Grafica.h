#ifndef GRAFICA_H_INCLUDED
#define GRAFICA_H_INCLUDED

class Grafica{
public:
    Grafica();
    Grafica(const Grafica &g);
    ~Grafica();
    Grafica& operator=(const Grafica &g);
    void AgregarNodo(char nombre);
    void EliminarNodo(char nom);
    void Vaciar();
    bool EstaVacia();
    void AgregarArista(char inicio, char fin);
    void EliminarArista();
    void VaciarNodo(); //Eliminar todas las aristas incidentes
    int NumNodos();
    int NumAristas();
    int Grado();
    bool BuscarNodo(char nom);
    bool BuscarArista(char inicio, char fin);
    void Imprimir();
private:
    int numNodos, numAristas;
    struct Nodo;
    struct Arista{
        Arista(Nodo *ady, Arista *sig = nullptr, Arista *ant = nullptr);
        Nodo * adyacente;
        Arista *siguiente, *anterior;
    };
    struct Nodo{
        Nodo(char nom, Nodo *sig = nullptr, Nodo *ant = nullptr);
        bool EstaVacio();
        void Agregar(Nodo *ady);
        void Eliminar(Nodo *ady);
        bool esAislado();
        void Aislar();
        Arista*BuscarDir(Nodo *ady);
        char nombre;
        int grado;
        Arista *primera, *ultima;
        Nodo *siguiente, *anterior;
    }*primero, *ultimo;

    Nodo *BuscarDireccion(char nom);
};
#endif // GRAFICA_H_INCLUDED

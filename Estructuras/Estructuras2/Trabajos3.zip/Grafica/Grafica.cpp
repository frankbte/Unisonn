#include "Grafica.h"

Grafica::Grafica(): numNodos(0), numAristas(0)
{
    primero = nullptr;
}

void Grafica::AgregarNodo(char nombre)
{
    if(!BuscarNodo(nombre)){
        Nodo * nuevo = new Nodo(nombre, nullptr, ultimo);
        (EstaVacia() ? primero : ultimo->siguiente) = nuevo;
        ultimo = nuevo;
        ++numNodos;
    }
}

void Grafica::AgregarArista(char inicio, char fin)
{
    Nodo *ptrInicio = BuscarDireccion(inicio);
    if(ptrInicio == nullptr) return;
    Nodo *ptrFin = BuscarDireccion(fin);
    if(ptrFin == nullptr) return;
    if(BuscarArista(inicio, fin))return;
    ptrInicio->Agregar(ptrFin);
    ptrFin->Agregar(ptrInicio);
    ++numAristas;
}

Grafica::Nodo::Nodo(char nom, Grafica::Nodo *sig, Grafica::Nodo *ant):
    nombre(nom), grado(0), primera(nullptr), ultima(nullptr),siguiente(sig), anterior(ant)
{

}

Grafica::Arista::Arista(Grafica::Nodo *ady,
    Grafica::Arista *sig, Grafica::Arista *ant):
    adyacente(ady), siguiente(sig), anterior(ant)
{

}

bool Grafica::BuscarNodo(char nom)
{

}

bool Grafica::EstaVacia()
{

}

Grafica::Nodo *Grafica::BuscarDireccion(char nom)
{
    Nodo *actual = primero;
    while(actual != nullptr && actual ->nombre != nom){
        actual = actual ->siguiente;
    }
    return actual;
}

void Grafica::Nodo::Agregar(Grafica::Nodo *ady)
{
    Grafica::Arista *nueva = new Grafica::Arista(ady, nullptr,ultima);
    (EstaVacio() ? primera : ultima ->siguiente) = nueva;
    ultima = nueva;
    ++grado;
}

bool Grafica::Nodo::esAislado()
{
    return grado == 0;
}

bool Grafica::BuscarArista(char inicio, char fin)
{

}

bool Grafica::Nodo::EstaVacio()
{

}

void Grafica::EliminarNodo(char nom)
{
    Nodo *porBorrar = BuscarDireccion(nom);
    if(porBorrar == nullptr) return;
    porBorrar->Aislar();

    (porBorrar == primero ? primero : porBorrar->anterior->siguiente) = porBorrar ->siguiente;
    (porBorrar == ultimo ? ultimo: porBorrar->siguiente ->anterior) = porBorrar ->anterior;

    delete porBorrar;
    --numNodos;
}

void Grafica::Nodo::Aislar()
{
    while(!esAislado()){
        primera->adyacente->Eliminar(this);
        Eliminar(primera->adyacente);
    }
}

void Grafica::Nodo::Eliminar(Grafica::Nodo *ady)
{
    Arista *porBorrar = BuscarDir(ady);
    if(porBorrar == nullptr) return;
    (porBorrar == primera ? primera : porBorrar->anterior->siguiente) = porBorrar->siguiente;
    (porBorrar ==ultima ? ultima : porBorrar->siguiente->anterior) = porBorrar->anterior;
    delete porBorrar;
    --grado;
}

Grafica::Arista * Grafica::Nodo::BuscarDir(Nodo *ady)
{
    Arista* actual = primera;
    while(actual != nullptr && actual->adyacente != ady){
        actual = actual ->siguiente;
    }
    return actual;
}

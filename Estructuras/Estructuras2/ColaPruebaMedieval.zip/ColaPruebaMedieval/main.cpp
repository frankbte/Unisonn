#include <iostream>
#include "cola.h"
using namespace std;

int main() {
    // Crear una cola medieval
    Cola<std::string> colaMedieval;

    // A�adir algunos ciudadanos a la cola
    colaMedieval.Encolar("Arturo", true);  // noble
    colaMedieval.Encolar("Merl�n", true);  // noble
    colaMedieval.Encolar("Lancelot", true); // noble
    colaMedieval.Encolar("Gawain", true);   // noble
    colaMedieval.Encolar("Gareth", false);  // plebeyo
    colaMedieval.Encolar("Ginebra", true);  // noble

    // Imprimir la cola
    colaMedieval.Imprimir();

    // Obtener el primer y �ltimo ciudadano de la cola
    Persona primero = colaMedieval.ObtenerPrimero();
    Persona ultimo = colaMedieval.ObtenerUltimo();

    std::cout << "Primer ciudadano: " << primero.ObtenerNombre() << " (" << (primero.esNoble() ? "noble" : "plebeyo") << ")" << std::endl;
    std::cout << "�ltimo ciudadano: " << ultimo.ObtenerNombre() << " (" << (ultimo.esNoble() ? "noble" : "plebeyo") << ")" << std::endl;

    // Desencolar un ciudadano
    colaMedieval.Desencolar();

    // Imprimir la cola despu�s de desencolar
    colaMedieval.Imprimir();

    return 0;
}

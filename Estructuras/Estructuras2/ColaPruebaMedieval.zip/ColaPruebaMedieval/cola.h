#ifndef COLA_H_INCLUDED
#define COLA_H_INCLUDED
#include "Persona.h"

template <typename T>
class Cola{
public:
    Cola();
    ~Cola();
    Cola(const Cola<T> &c);
    void Encolar(T valor, bool esNoble);
    void Desencolar();
    int ObtenerTam();
    Persona ObtenerPrimero();
    Persona ObtenerUltimo();
    bool EstaVacia();
    void Vaciar();
    void Imprimir();

private:
    int tam;
    struct Elemento{
        T valor;
        bool esNoble;
        Elemento *siguiente;
    }*primero, *ultimo;

};

#include "cola.tpp"

#endif // COLA_H_INCLUDED

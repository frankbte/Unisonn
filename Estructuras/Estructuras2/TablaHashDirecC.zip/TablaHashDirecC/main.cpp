#include <iostream>
#include "Lista.h"
#include "TablaHash.h"
#include "utilerias.h"

using namespace std;

int main()
{
}

#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

template<typename T>
class Lista{
public:
    Lista(); //ya
    ~Lista(); // ya
    Lista(const Lista<T> &l);
    void AgregarEnInicio(T valor); // ya
    void AgregarAlFinal(T valor); // ya
    void AgregarEnIndice(int indice, T valor); // ya
    void EliminarDeInicio(); // ya
    void EliminarDeFinal(); //ya
    void EliminarEnIndice(int indice); // ya
    bool BuscarValor(T valor); //saber si est� o no
    int BuscarPos(T valor); //retornar indice
    bool EstaVacia(); // ya
    T ObtenerPrimero(); // ya
    T ObtenerUltimo(); // ya
    T ObtenerValorEnIndice(int indice); // ya
    void ModificarValorEnIndice(int indice, T nuevoValor); // ya
    int Tamano(); // ya
    void Vaciar(); // ya
    void Imprimir(); // ya

private:
    int tam;
    struct Elemento{
        T valor;
        Elemento *siguiente;
        Elemento *anterior;
    }*primero, *ultimo;
};

#include "Lista.tpp"

#endif // LISTA_H_INCLUDED

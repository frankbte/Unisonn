#include <iostream>
#include "Lista.h"

using namespace std;
int main() {
    Lista<int> lista;

    char respuesta;

    do {
        cout << "Que accion desea realizar?" << endl;
        cout << "a: Agregar elementos" << endl;
        cout << "e: Eliminar elementos" << endl;
        cout << "c: Consultar un elemento" << endl;
        cout << "s: Salir" << endl;
        cout << "Ingrese la letra de su opcion: ";
        cin >> respuesta;

        switch (respuesta) {
            case 'a':
                char opcionAgregar;
                cout << "Donde desea agregar el elemento? (i: Inicio, f: Final, o: Indice): ";
                cin >> opcionAgregar;

                int valorAgregar, indiceAgregar;
                switch (opcionAgregar) {
                    case 'i':
                        cout << "Ingrese el valor a agregar al inicio de la lista: ";
                        cin >> valorAgregar;
                        lista.AgregarEnInicio(valorAgregar);
                        break;
                    case 'f':
                        cout << "Ingrese el valor a agregar al final de la lista: ";
                        cin >> valorAgregar;
                        lista.AgregarAlFinal(valorAgregar);
                        break;
                    case 'o':
                        cout << "Ingrese el valor a agregar: ";
                        cin >> valorAgregar;
                        cout << "Ingrese el indice donde desea agregar el elemento: ";
                        cin >> indiceAgregar;
                        try {
                            lista.AgregarEnIndice(indiceAgregar, valorAgregar);
                        } catch (const out_of_range& e) {
                            cerr << "Error al agregar elemento en el indice: " << e.what() << endl;
                        }
                        break;
                    default:
                        cout << "Opcion no valida." << endl;
                }
                system("cls");

                cout << "Lista despues de agregar el elemento: " << endl;
                cout << "La lista tiene: " << lista.Tamano() << " elementos" << endl;
                lista.Imprimir();
                cout << endl;
                break;

            case 'e':
                char opcionEliminar;
                cout << "Como desea eliminar el elemento? (i: Inicio, f: Final, o: Indice, v: Vaciar): ";
                cin >> opcionEliminar;

                switch (opcionEliminar) {
                    case 'i':
                        try {
                            lista.EliminarDeInicio();
                            cout << "Elemento eliminado correctamente." << endl;
                        } catch (const out_of_range& e) {
                            cerr << "Error al eliminar elemento: " << e.what() << endl;
                        }
                        break;
                    case 'f':
                        try {
                            lista.EliminarDeFinal();
                            cout << "Elemento eliminado correctamente." << endl;
                        } catch (const out_of_range& e) {
                            cerr << "Error al eliminar elemento: " << e.what() << endl;
                        }
                        break;
                    case 'o':
                        int indiceEliminar;
                        cout << "Ingrese el indice del elemento que desea eliminar: ";
                        cin >> indiceEliminar;
                        try {
                            lista.EliminarEnIndice(indiceEliminar);
                            cout << "Elemento eliminado correctamente." << endl;
                        } catch (const out_of_range& e) {
                            cerr << "Error al eliminar elemento: " << e.what() << endl;
                        }
                        break;
                    case 'v':
                        try{
                            lista.Vaciar();
                            cout << "Lista vaciada correctamente." << endl;
                        }catch (const out_of_range& e) {
                            cerr << "Error al vaciar la lista: " << e.what() << endl;
                        }
                        break;
                    default:
                        cout << "Opcion no valida." << endl;
                }
                system("cls");

                cout << "Lista despues de eliminar el elemento: " << endl;
                cout << "La lista tiene: " << lista.Tamano() << " elementos" << endl;
                lista.Imprimir();
                cout << endl;
                break;

            case 'c':
                int indiceConsultar;
                cout << "Ingrese el indice del elemento que desea consultar: ";
                cin >> indiceConsultar;
                try {
                    cout << "El elemento en el indice " << indiceConsultar << " es: " << lista.ObtenerValorEnIndice(indiceConsultar) << endl;
                } catch (const out_of_range& e) {
                    cerr << "Error al consultar el elemento: " << e.what() << endl;
                }
                break;

            case 's':
                cout << "Saliendo del programa." << endl;
                break;

            default:
                cout << "Opcion no valida." << endl;
        }

    } while (respuesta != 's');

    cout << "Lista final: " << endl;
    lista.Imprimir();

    cout << endl;

    cout << "Programa terminado." << endl;
    return 0;
}

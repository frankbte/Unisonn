#ifndef BSTAR_H_INCLUDED
#define BSTAR_H_INCLUDED

#define N 4

#include <iostream>

struct Nodo {
    int valor[N - 1];
    Nodo* raiz = NULL;
    Nodo* hijos[N]; // Arreglo de hijos de tama�o n
    int esHoja; // Usamos este valor para saber si el nodo es hijo o no, esHijo = 1 SI, esHijo = 0 NO
    int n;
    Nodo* padre; //Puntero al nodo padre del arbol
};

Nodo* BuscarHoja(Nodo* raiz, int k, Nodo* padre, int indiceHijo);
Nodo* Agregar(Nodo* raiz, int k);


#include "Bstar.tpp"

#endif // BSTAR_H_INCLUDED

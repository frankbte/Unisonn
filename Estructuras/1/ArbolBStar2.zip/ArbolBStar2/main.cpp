#include "Bstar.h"

int main()
{
    Nodo* raiz = NULL;
    raiz = Agregar(raiz, 6);
    raiz->hijos[0] = Agregar(raiz->hijos[0], 1);
    raiz->hijos[0] = Agregar(raiz->hijos[0], 2);
    raiz->hijos[0] = Agregar(raiz->hijos[0], 4);
    raiz->hijos[0]->padre = raiz;
    raiz->hijos[1] = Agregar(raiz->hijos[1], 7);
    raiz->hijos[1] = Agregar(raiz->hijos[1], 8);
    raiz->hijos[1] = Agregar(raiz->hijos[1], 9);
    raiz->hijos[1]->padre = raiz;

    std::cout << "Original tree: " << std::endl;
    for (int i = 0; i < raiz->n; i++)
        std::cout << raiz->valor[i] << " ";
    std::cout << std::endl;
    for (int i = 0; i < 2; i++) {
        std::cout << raiz->hijos[i]->valor[0] << " ";
        std::cout << raiz->hijos[i]->valor[1] << " ";
        std::cout << raiz->hijos[i]->valor[2] << " ";
    }
    std::cout << std::endl;

    std::cout << "After adding 5: " << std::endl;

    raiz->hijos[0] = Agregar(raiz->hijos[0], 5);

    for (int i = 0; i <= raiz->n; i++)
        std::cout << raiz->valor[i] << " ";
    std::cout << std::endl;
    for (int i = 0; i < N - 1; i++) {
        std::cout << raiz->hijos[i]->valor[0] << " ";
        std::cout << raiz->hijos[i]->valor[1] << " ";
    }

    return 0;
}

/**
 * Universidad de Sonora - Estructura de Datos
 * Rubén Romero | 24 de mayo del 2023
 * Tarea #15: Heap (Montículo)
 */
#ifndef HEAP_H
#define HEAP_H

/**
 * Includes básicos
 */
#include <cstddef>
#include <iostream>
#include <cstring>
#include <cmath>

/**
 * Obtiene el índice del padre en relación al índice solicitado.
 * @param indice elemento en el arreglo a operar
 */
signed int obtener_indice_padre(signed int indice);
/**
 * Obtiene el índice del hijo izquierda en relación al índice solicitado.
 * @param indice elemento en el arreglo a operar
 */
signed int obtener_hijo_izquierda(signed int indice);
/**
 * Obtiene el índice del hijo derecha en relación al índice solicitado.
 * @param indice elemento en el arreglo a operar
 */
signed int obtener_hijo_derecha(signed int indice);
/**
 * Definición de función de utilería para cambiar referencias.
 * @tparam T El tipo de elementos a operar.
 * @param[in] a Primer valor a comparar.
 * @param[in] b Segundo valor a comparar.
 */
template <typename T>
void swap(const T &a, const T &b);
/**
 * Definición de función de criterio de ordenamiento (Mínimo).
 * @tparam T El tipo de elementos a operar.
 * @param[in] a Primer valor a comparar.
 * @param[in] b Segundo valor a comparar.
 * @return condicion
 */
template <typename T>
bool min(const T &a, const T &b);
/**
 * Definición de función de criterio de ordenamiento (Máximo).
 * @tparam T El tipo de elementos a operar.
 * @param[in] a Primer valor a comparar.
 * @param[in] b Segundo valor a comparar.
 * @return condicion
 */
template <typename T>
bool max(const T &a, const T &b);

/**
 * Definición de clase heap (montículo).
 * @tparam T El tipo de elementos que se podrá almacenar en el heap (montículo).
 */
template <typename T, bool (*F)(const T &a, const T &b) = min>
class Heap
{
private:
	/**
	 * Puntero al arreglo dinámico de elementos en memoria.
	 */
  T *_elementos;
	/**
	 * Capacidad de elementos del arreglo dinámico.
	 */
  unsigned int _capacidad;
	/**
	 * Índice del elemento al final del heap.
	 */
  signed int _ultimo;
	/**
	 * Cambia los valores hacia arriba en relación al índice.
	 * @param indice elemento en el arreglo a operar.
	 */
	void _cambiar_hacia_arriba(signed int indice);
	/**
	 * Cambia los valores hacia abajo en relación al índice.
	 * @param indice elemento en el arreglo a operar
	 */
	void _cambiar_hacia_abajo(signed int indice);
	/**
	 * Redimensiona la capacidad del arreglo acordemente a la 
	 * cantidad de elementos requeridos de cada nivel, incrementando
	 * el nivel por uno.
	 */
	void _redimensionar();

public:
	/**
	 * Constructor por default.
	 * @param niveles Número inicial de niveles en el heap.
	 */
	Heap(unsigned int niveles = 5);
	/**
	 * Constructor de copias.
	 * @param[in] heap Instancia por copiar.
	 */
	Heap(const Heap<T, F> &heap);
  /**
	 * Destructor de instancia.
	 */
	~Heap();
  /**
	 * Agrega un elemento al heap (montículo).
	 * @param elemento Valor por agregar.
	 */
	void Agregar(const T elemento);
  /**
	 * Elimina la raíz actual del heap.
	 */
	void EliminarRaiz();
  /**
	 * Obtiene el valor guardado en la raiz de la estructura.
	 * @return Instancia actual.
	 */
	T ObtenerRaiz();
  /**
	 * Obtiene si la estructura esta no tiene elementos.
	 * @return Está vacío o no.
	 */
	bool EstaVacio();
  /**
	 * Elimina todos los elementos del heap.
	 */
	void Vaciar();
  /**
	 * Obtiene la cantidad de elementos guardados en el heap.
	 * @return Número de elementos.
	 */
	unsigned int ObtenerNumeroElementos();
  /**
   * @note Para pruebas.
	 * Obtiene la capacidad del arreglo dinámico.
	 * @return Capacidad de arreglo dinámico.
	 */
  unsigned int ObtenerCapacidad();
  /**
   * @note Para pruebas, imprime cada elemento con sus relaciones.
	 * Obtiene la capacidad del arreglo dinámico.
	 */
  void Imprimir();
	/**
   * @note Para pruebas, imprime cada elemento.
	 * Obtiene la capacidad del arreglo dinámico.
	 */
  void ImprimirLista();
	/**
	 * @param[in] heap Valor a asignar.
	 * @return Instancia actual.
	 */
	Heap<T, F> &operator=(const Heap<T, F> &heap);
  /**
	 * Excepción exclusiva para clase Heap.
	 */
	class ExcepcionHeapVacio : public std::exception
	{
		public:
			/**
			 * Sobrecarga a la funcion what() de std::exception, mensaje personalizado.
			 */
			const char *what() const throw()
			{
				return "error: heap: el montículo está vacío";
			}
  };
};

#include "./Heap.tpp"

#endif
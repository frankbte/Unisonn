#ifndef MONTICULO_H_INCLUDED
#define MONTICULO_H_INCLUDED

#include <cstddef>
#include <iostream>
#include <cstring>
#include <cmath>


signed int obtener_indice_padre(signed int indice);

signed int obtener_hijo_izquierda(signed int indice);

signed int obtener_hijo_derecha(signed int indice);

template <typename T>
void swap(const T &a, const T &b);

template <typename T>
bool min(const T &a, const T &b);

template <typename T>
bool max(const T &a, const T &b);


template <typename T, bool (*F)(const T &a, const T &b) = min>
class Heap
{
private:

  T *_elementos;

  unsigned int _capacidad;

  signed int _ultimo;

	void _cambiar_hacia_arriba(signed int indice);

	void _cambiar_hacia_abajo(signed int indice);
	/**
	 * Redimensiona la capacidad del arreglo acordemente a la
	 * cantidad de elementos requeridos de cada nivel, incrementando
	 * el nivel por uno.
	 */
	void _redimensionar();

public:
	/**
	 * Constructor por default.
	 * @param niveles N�mero inicial de niveles en el heap.
	 */
	Heap(unsigned int niveles = 5);
	/**
	 * Constructor de copias.
	 * @param[in] heap Instancia por copiar.
	 */
	Heap(const Heap<T, F> &heap);
  /**
	 * Destructor de instancia.
	 */
	~Heap();
  /**
	 * Agrega un elemento al heap (mont�culo).
	 * @param elemento Valor por agregar.
	 */
	void Agregar(const T elemento);
  /**
	 * Elimina la ra�z actual del heap.
	 */
	void EliminarRaiz();
  /**
	 * Obtiene el valor guardado en la raiz de la estructura.
	 * @return Instancia actual.
	 */
	T ObtenerRaiz();
  /**
	 * Obtiene si la estructura esta no tiene elementos.
	 * @return Est� vac�o o no.
	 */
	bool EstaVacio();
  /**
	 * Elimina todos los elementos del heap.
	 */
	void Vaciar();
  /**
	 * Obtiene la cantidad de elementos guardados en el heap.
	 * @return N�mero de elementos.
	 */
	unsigned int ObtenerNumeroElementos();
  /**
   * @note Para pruebas.
	 * Obtiene la capacidad del arreglo din�mico.
	 * @return Capacidad de arreglo din�mico.
	 */
  unsigned int ObtenerCapacidad();
  /**
   * @note Para pruebas, imprime cada elemento con sus relaciones.
	 * Obtiene la capacidad del arreglo din�mico.
	 */
  void Imprimir();
	/**
   * @note Para pruebas, imprime cada elemento.
	 * Obtiene la capacidad del arreglo din�mico.
	 */
  void ImprimirLista();
	/**
	 * @param[in] heap Valor a asignar.
	 * @return Instancia actual.
	 */
	Heap<T, F> &operator=(const Heap<T, F> &heap);
  /**
	 * Excepci�n exclusiva para clase Heap.
	 */
	class ExcepcionHeapVacio : public std::exception
	{
		public:
			/**
			 * Sobrecarga a la funcion what() de std::exception, mensaje personalizado.
			 */
			const char *what() const throw()
			{
				return "error: heap: el mont�culo est� vac�o";
			}
  };
};


#include "./Monticulo.tpp"

#endif // MONTICULO_H_INCLUDED

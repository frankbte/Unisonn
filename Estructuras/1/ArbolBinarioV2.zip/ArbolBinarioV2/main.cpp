
#include <iostream>
#include <cstdlib>


#include "Arbol.h"
using namespace std;

int main()
{

    ABB<int> arbol;


    arbol.Insertar(55);
    arbol.Insertar(1);
    arbol.Insertar(25);
    arbol.Insertar(15);
    arbol.Insertar(6);
    arbol.Insertar(12);

    arbol.ImprimirInOrden();


    return 0;
}

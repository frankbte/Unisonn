#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED

#include <cstdlib>
#include <iostream>

template<typename T>
class ABB{

public:
    ABB();
    ~ABB();
    //ABB(const ABB & r);
    //ABB& operator=(const ABB& r);
    void Insertar(T valor);
    void Eliminar(T valor);
    bool Buscar(T valor);
    int NumNodos();
    int AlturaArbol();
    bool EstaVacio();
    void Vaciar();
    void ImprimirInOrden();
    void ImprimirInOrdenInverso();
    void ImprimirPorNiveles();
    void ImprimirPreOrden();
    void ImprimirPostOrden();
    int BuscarMayor();
    int BuscarMenor();
    void ImprimirFactoresDeEquilibrio();


private:

    struct Nodo{
    T valor;
    Nodo* hijoIzq;
    Nodo* hijoDer;
    Nodo(T v, Nodo* hIzq = NULL, Nodo* hDer = NULL);
    }*raiz;

    int numNodos;
    int altura;

    void Insertar(Nodo *& r, T valor);
    Nodo *& Eliminar(Nodo *& r, T valor);
    bool Buscar(Nodo *& r, T valor);
    Nodo *& BuscarMenor(Nodo *& r);
    Nodo *& BuscarMayor(Nodo *& r);
    int AlturaArbol(Nodo *& r);
    void ImprimirInOrden(Nodo *& r);
    void ImprimirInOrdenInverso(Nodo *& r);
    void ImprimirPorNiveles(Nodo *& r);
    void ImprimirPostOrden(Nodo *& r);
    void ImprimirPreOrden(Nodo *& r);
    void CopiarPreOrden(Nodo *& r);
    void Podar(Nodo *& r);
    void ImprimirFactoresDeEquilibrio(Nodo *& r);
    int FactorEquilibrio(Nodo * r);

};
#include "Arbol.tpp"
#endif // ARBOL_H_INCLUDED

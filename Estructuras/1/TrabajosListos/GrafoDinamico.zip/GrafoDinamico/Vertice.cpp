#include "Vertice.h"

using namespace std;

Vertice::Vertice(string _nombre)
{
    nombre = _nombre;
    sig = NULL;
    ari = NULL;
}

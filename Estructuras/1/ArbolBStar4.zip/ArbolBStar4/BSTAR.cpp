#include "BSTAR.h"
 using namespace std;


 // ------------------------ Metodos auxiliares ----------------------------------------------

BSTAR* BSTAR::EncontrarNodo(BSTAR* nodo, int llave)
{
    int i = 0;
    while(i < nodo->numllaves && llave > nodo->llaves[i]){
        i++;
    }
    if(nodo->esHoja){
        return nodo;
    }else {
        return EncontrarNodo(nodo-> hijo[i], llave);
    }
}

void BSTAR::InsertarNoCompleto(BSTAR *nodo, int llave)
{
    int i = nodo->numllaves - 1;
    if(nodo->esHoja){
        while(i >= 0 && llave < nodo->llaves[i]){
            nodo->llaves[i + 1] = nodo->llaves[i];
            i--;
        }
        nodo->llaves[i + 1] = llave;
        nodo->numllaves++;
    }else{
        while(i >= 0 && llave < nodo->llaves[i]){
            i--;
        }
        i++;
        if(nodo->hijo[i]->numllaves == (2 * t) - 1){
            DivNodo(nodo->hijo[i]);
            if(llave > nodo->llaves[i]){
                i++;
            }
        }
        InsertarNoCompleto(nodo->hijo[i], llave);
    }
}

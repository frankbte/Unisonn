#ifndef BSTAR_H_INCLUDED
#define BSTAR_H_INCLUDED

#include <iostream>

/*  Condiciones que se deben de cumplir en un Arbol B*:
    Suponiendo que tenemos un arbol de grado N
    - El nodo raiz tiene que tener como minimo 2 y maximo ((2N-2)/3)+1 hijos.
    - Todos los nodos excepto por la raiz y las hojas, tienen que tener como m�nimo (2N-1)/3 hijos (se redondea el valor).
        Eso quiere decir que si tenemos un arbol de grado 4, entonces tenemos (2*4-1)/3 hijos, que ser�an 2.33.
        En caso de tener decimal, el numero se redondea a partir de .5, si sube de .5 se redondea al siguiente numero entero.
        En caso contrario, el numero se redondea hacia el numero anterior mas cercano.
        En este caso si redondea a 2.


*/
class BSTAR{
public:
    BSTAR(); //Constructor
    ~BSTAR(); //Destructor
    BSTAR(const BSTAR *r); //
    //Insertar
    void Insertar(int llave);
    //Eliminar
    void Eliminar(int llave);
    //Buscar
    bool Buscar(int llave);
    //Dividir nodo
    void DivNodo(BSTAR* nodo);
    //Juntar nodos
    void JuntarNodos(BSTAR* nodoIzq, BSTAR* nodoDer);
    //Buscar nodo
    BSTAR* EncontrarNodo(BSTAR *nodo, int llave);
    //Buscar predecesor
    int ObtPredecesor(BSTAR *nodo);
    //Buscar sucesor
    int ObtSucesor(BSTAR *nodo);
    //Insertar en nodo que no est� lleno
    void InsertarNoCompleto(BSTAR *nodo, int llave);

private:

    struct Nodo{
    int numllaves; // Numero de claves almacenadas en un Nodo
    bool esHoja; // Cuando este valor es 1, el nodo es hoja, es 0 si no lo es
    int *llaves; // Arreglo de grado-1 llaves que puede contener un nodo
    BSTAR **hijo;
    //Nodo* hijos[grado]; // Arreglo del mismo tama�o que el grado del arbol que indica la cantidad de hijos que puede tener un Nodo
    }padre, raiz; // Punteros hacia el padre de un nodo y hacia la raiz del arbol

    int grado; // Variable que define el grado del arbol
    int altura;

};

#endif // BSTAR_H_INCLUDED

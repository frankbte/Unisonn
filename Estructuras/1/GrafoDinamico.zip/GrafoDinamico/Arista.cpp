#include "Arista.h"

Arista::Arista(Vertice* _dest, int _precio)
{
    dest = _dest;
    precio = _precio;
    sig = NULL;
}

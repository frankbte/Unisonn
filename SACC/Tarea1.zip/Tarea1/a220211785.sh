mkdir a220211785
ls > directorio.txt
echo : "Nombre: Francisco, Expediente: 220211785" >> directorio.txt
mv directorio.txt a220211785/
cd a220211785
cat directorio.txt

